/*
==================================================================================
asteroidsGame.cpp
==================================================================================
*/

#include "asteroidsGame.h"

vector<cTexture*> theGameTextures;
vector<cAsteroid*> theAsteroids;
vector<cBullet*> theRocketBullets;
